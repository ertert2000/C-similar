﻿chrome.webRequest.onAuthRequired.addListener(
    function (details) {
        return {
            authCredentials: {
                username: "851f66e5a7",
                password: "7e6aca5ae1"
            }
        };
    },
    { urls: ["<all_urls>"] },
    ['blocking']
);