#pragma once
#include <string>

void ListDrives();
void ShowDriveInfo(const std::wstring& drive);