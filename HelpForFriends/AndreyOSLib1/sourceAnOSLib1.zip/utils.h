#pragma once
#include <string>
#include <windows.h>
#include <iostream>
#include <windows.h>

void PrintFileTime(const FILETIME& fileTime);