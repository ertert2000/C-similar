#pragma once
#include <string>

void CreateDirectory(const std::wstring& dirName);
void RemoveDirectory(const std::wstring& dirName);
